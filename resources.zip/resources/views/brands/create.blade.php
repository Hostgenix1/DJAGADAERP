@extends('layouts.app')

@section('title', 'New Brand')

{{--
  Create Brand - Products Module
  Module: Products
  Features: Brand creation form, reusable form partial, name/description fields, validation, save/cancel actions
  Version: 1.0.0
--}}

@section('content')
<div class="row">
    <div class="col-lg-8">
        <div class="card card-primary card-outline">
            <div class="card-header">
                <h3 class="card-title"><i class="fas fa-tag mr-1"></i> New Brand</h3>
            </div>
            <div class="card-body">
                <form method="POST" action="{{ route('brands.store') }}">
                    @csrf

                    @include('brands.partials.form', ['form' => null])
                    <div class="mt-3">
                        <button class="btn btn-primary"><i class="fas fa-save"></i> Save</button>
                        <a href="{{ route('brands.index') }}" class="btn btn-default">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection
