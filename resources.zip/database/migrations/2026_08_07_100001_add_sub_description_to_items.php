<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('invoice_items', function (Blueprint $table) {
            $table->string('sub_description')->nullable()->after('description');
        });

        Schema::table('quote_items', function (Blueprint $table) {
            $table->string('sub_description')->nullable()->after('description');
        });
    }

    public function down(): void
    {
        Schema::table('invoice_items', function (Blueprint $table) {
            $table->dropColumn('sub_description');
        });

        Schema::table('quote_items', function (Blueprint $table) {
            $table->dropColumn('sub_description');
        });
    }
};
